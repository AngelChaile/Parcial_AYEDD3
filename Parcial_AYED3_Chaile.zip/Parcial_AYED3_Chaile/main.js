window.onload = function(){
//AGREGAR OPCIONES AL SELECT
let select = document.getElementById("ciudad");

let marianoAcosta = document.createElement("option");
marianoAcosta.value = "MarianoAcosta";
marianoAcosta.innerText = "Mariano Acosta";
select.appendChild(marianoAcosta);

let agustinFerrari = document.createElement("option");
agustinFerrari.value = "Agustin Ferrari";
agustinFerrari.innerText = "Agustin Ferrari";
select.appendChild(agustinFerrari);

let merlo = document.createElement("option");
merlo.value = "merlo";
merlo.innerText = "Merlo";
select.appendChild(merlo);

let padua = document.createElement("option");
padua.value = "padua";
padua.innerText = "S.A de Padua";
select.appendChild(padua);

let libertad = document.createElement("option");
libertad.value = "Libertad";
libertad.innerText = "Libertad";
libertad.selected = true;
select.appendChild(libertad);

let pontevedra = document.createElement("option");
pontevedra.value = "pontevedra";
pontevedra.innerText = "Pontevedra";
select.appendChild(pontevedra);

//CREO LA LISTA ORDENADA A UTILIZAR Y LA CANTIDAD
let ol = document.createElement("ol");
let cantidadEmpleados = document.createElement("p");

let button = document.querySelector("button");
button.addEventListener("click", function () {
    
    //RECOLECCION DE DATOS 
    let nombre = document.getElementById("nombre");
    let apellido = document.getElementById("apellido");
    let salario = document.getElementById("salario");
    let fecha = document.getElementById("fecha");
    let color = document.getElementById("color");
    
    //VALIDACION DE DATOS OBLIGATORIOS
    if (nombre.value === "" || apellido.value === "" || salario.value === "") {
        alert("Todos los campos son obligatorios exepto la fecha de nacimiento");
        console.error("Falto rellenar el formulario")
        return;
    }
    
    //CREACIÓN DE LA LISTA ORDENADA CON DATOS DE LOS EMPLEADOS NUEVOS
    const nuevoEmpleado = document.createElement('li');
    nuevoEmpleado.innerText = `${nombre.value} | ${apellido.value} | Salario bruto: $${salario.value}`;
    ol.appendChild(nuevoEmpleado);
    document.body.appendChild(ol);

    //ACTUALIZAMOS LA CANTIDAD DE EMPLEADOS
    cantidadEmpleados.innerText = `Cantidad de empleados: ${ol.children.length}`;
    document.body.appendChild(cantidadEmpleados);

    //VACIAR LOS CAMPOS
    nombre.value = "";
    apellido.value = "";
    salario.value = "";
    fecha.value = "";
    color.value = "";

    
})

}